md5 for nodejs

### project is base on https://github.com/blueimp/JavaScript-MD5/tree/master/js


##usage

```
var md5 = require('node-md5');
md5('hello world');
// 5eb63bbbe01eeed093cb22bb8f5acdc3
```