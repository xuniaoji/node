# mongoose-legacy-pluralize
Legacy pluralization logic for mongoose
